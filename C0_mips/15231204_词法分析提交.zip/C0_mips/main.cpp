
#include "global.h"


using namespace std;

int main()
{
    //cout << "Hello world!" << endl;
    readCodeFile();
    return 0;
}
