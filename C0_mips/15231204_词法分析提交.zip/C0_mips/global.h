#ifndef GLOBAL_H_INCLUDED
#define GLOBAL_H_INCLUDED
#include <iostream>
#include <fstream>
#include <cassert>
#include <string>
#include<map>
#include <stdlib.h>
#include <string.h>

void readCodeFile();

#endif // GLOBAL_H_INCLUDED
