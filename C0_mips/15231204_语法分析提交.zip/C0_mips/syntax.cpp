#include "global.h"

char* pre1p;
char* pre2p;
char* pre3p;

int flag_for_interger2const;
int level = 0;
bool return_flag = false;
bool return_expression = false;     //Ϊfalse˵������ֵΪvoid������ʽΪ�գ�
string return_type = string("VOIDSY");


void nextsym()            //�﷨����ȡ���ʣ�3��prep���ڱ�ʶ�������飬��������ʱ��Ҫ��Ԥ��
{
    pre3p = pre2p;
    pre2p = pre1p;
    pre1p = p;
    getsym();
    Getchar();
}

void recallsym()          //�������������ʱʹ�ã���p���˺��ٵ�����Ӧ�����﷨��������
{
    char* current_p = p;
    p = pre1p;
    Ch = *p;
    pre1p = pre2p;
    pre2p = pre3p;
    char* temp = p;
    while(temp < current_p)
    {
        if(*temp == '\n')
            line_num--;
        temp ++;
    }
}

//���������壾   ::=   int����ʶ��������������{,����ʶ��������������}
//                           | char����ʶ���������ַ���{,����ʶ���������ַ���}
//���޷���������  ::= ���������֣��������֣���
//��������        ::= �ۣ������ݣ��޷�������������
//����ʶ����    ::=  ����ĸ��������ĸ���������֣���
void next_semi()
{
    while(symbol.compare("SEMI")!=0)
    {
        nextsym();
    }
    nextsym();
}

void next_RBRACE()
{
    while(symbol.compare("RBRACE")!=0)
    {
        nextsym();
    }
    nextsym();
}

void next_LBRACE()
{
    while(symbol.compare("LBRACE")!=0)
    {
        nextsym();
    }
    nextsym();
}

void next_declare_head()
{
    nextsym();
    while((symbol.compare("INTSY")!=0) && (symbol.compare("CHARSY")!=0) && (symbol.compare("VOIDSY")!=0))
    {
        nextsym();
    }
}

void next_RPAR()
{
    while(symbol.compare("RPAR")!=0)
    {
        nextsym();
    }
}

void next_statement()
{
    while((symbol.compare("IFSY")!=0) && (symbol.compare("DOSY")!=0) && (symbol.compare("SWITCHSY")!=0) &&
          (symbol.compare("LBRACE")!=0) && (symbol.compare("IDSY")!=0) && (symbol.compare("SCANFSY")!=0) &&
          (symbol.compare("PRINTSY")!=0) && (symbol.compare("SEMI")!=0) && (symbol.compare("RETURNSY")!=0))
          {
              nextsym();
          }
}

int integer()
{
    flag_for_interger2const = 0;
    int NUM = 0;
    int flag = 1;
    if((symbol.compare("PLUS")==0)|| (symbol.compare("MINUS")==0))
    {
        if(symbol.compare("MINUS")==0)
        {
            flag = -1;
        }
        nextsym();
    }
    if(symbol.compare("NUMSY")==0)
    {
        if(*pre1p!='0' || (p-pre1p)<2)
        {
            NUM = flag*num;
            cout<<"This is integer" <<" in line "<< line_num<< endl;
            nextsym();
        }
        else
        {
            error(9);
            next_semi();
            flag_for_interger2const = 1;
        }
    }
    return NUM;
}

void constdefine()
{
    while(symbol.compare("CONSTSY") == 0)
    {
        nextsym();
        string type;
        if(symbol.compare("INTSY") == 0)
        {
            type = string("INTSY");
            nextsym();
            if(symbol.compare("IDSY") == 0)
            {
                string Name = string(IDNAME);
                nextsym();
                if(symbol.compare("EQUAL") == 0)
                {
                    nextsym();
                    int NUM = integer();
                    if(flag_for_interger2const == 1)
                    {
                        continue;
                    }
                                    ////////////////////////////Ƿһ�����ű�����
                ////////////////////////////�Լ��м��������
                ////////////////////////////
                }
                else
                {
                    error(10);
                    next_semi();
                    continue;
                }
            }
            else
            {
                error(8);
                next_semi();
                continue;
            }
            int flag = 0;
            while(symbol.compare("COMMA")==0)
            {
                nextsym();
                if(symbol.compare("IDSY")==0)
                {
                    string Name = string(IDNAME);
                    nextsym();
                    if(symbol.compare("EQUAL")==0)
                    {
                        nextsym();
                        int NUM = integer();
                        if(flag_for_interger2const == 1)
                        {
                            continue;
                        }
//////////////////////////////////////////////////////Ƿһ������
                        ///////////////////////�Լ��м��������
                        ///////////
                    }
                    else
                    {
                        error(10);
                        flag = 1;
                        break;
                    }
                }
                else
                {
                    error(8);
                    flag = 1;
                    break;
                }
            }
            if(flag == 1)
            {
                next_semi();
                continue;
            }
        }
        else if(symbol.compare("CHARSY")==0)
        {
            type = string("CHARSY");
            nextsym();
            if(symbol.compare("IDSY")==0)
            {
                string Name = string(IDNAME);
                nextsym();
                int ascii;
                if(symbol.compare("EQUAL")==0)
                {
                    nextsym();

                    if(symbol.compare("CHARASCII")==0)
                    {
                        ascii = singleCHAR;

                        nextsym();
                    }
                    else
                    {
                        error(11);
                        next_semi();
                        continue;
                    }
                    /////////////////////////////Ƿ����ű�
                        /////////////////////////////�Լ��м��������
                        /////////////////////////////
                }
                else
                {
                    error(10);
                    next_semi();
                    continue;
                }
            }
            else
            {
                error(8);
                next_semi();
                continue;
            }
            int flag = 0;
            while(symbol.compare("COMMA")==0)
            {
                nextsym();
                if(symbol.compare("IDSY")==0)
                {
                    string Name = string(IDNAME);
                    nextsym();
                    int ascii;
                    if(symbol.compare("EQUAL")==0)
                    {
                        nextsym();
                        if(symbol.compare("CHARASCII")==0)
                        {   ascii = singleCHAR;

                            nextsym();
                        }
                        else
                        {
                            error(11);
                            flag = 1;
                            break;
                        }
                        /////////////////////////////Ƿ����ű�
                            /////////////////////////////�Լ��м��������
                            /////////////////////////////
                    }
                    else
                    {
                        error(10);
                        flag = 1;
                        break;
                    }
                }
                else
                {
                    error(8);
                    flag = 1;
                    break;
                }
            }
            if(flag == 1)
            {
                next_semi();
                continue;
            }
        }
        else
        {
            error(6);
            next_semi();
            continue;
        }
        if(symbol.compare("SEMI")!=0)
        {
            error(12);
        }
        cout << "This is const define!" <<" in line "<< line_num <<endl;
        nextsym();
    }
}

void functiondefine()
{
    while((symbol.compare("INTSY")==0) || (symbol.compare("CHARSY")==0) || (symbol.compare("VOIDSY")==0))
    {
        level++;
        string type = symbol;
        return_type = symbol;
        nextsym();
        if(symbol.compare("MAINSY")==0)
        {
            recallsym();
            recallsym();
            level--;
            nextsym();
            return;
        }
        if(symbol.compare("IDSY")==0)
        {
            string Name = string(IDNAME);
            nextsym();
            if(symbol.compare("LPAR")==0)
            {
                nextsym();
                ////////////////////ȱ�������
                ///////////////////
                int paranum = paratable();
                if(symbol.compare("RPAR")==0)
                {
                    nextsym();
                    ////////////////ȱ���ű�����
                    if(symbol.compare("LBRACE")!=0)
                    {
                        error(14);
                        next_RBRACE();
                        continue;
                    }
                }
                else
                {
                    error(15);
                    next_RBRACE();
                    continue;
                }
            }
            else
            {
                error(16);
                next_RBRACE();
                continue;
            }
        }
        else
        {
            error(8);
            next_RBRACE();
            continue;
        }
        next_LBRACE();
        compoundstatement();
        if(symbol.compare("RBRACE")!=0)
        {
            error(17);
            next_declare_head();
            continue;
        }
        //////////////ȱ�������ű�ɾ��
        ///////////////ȱ���������������
        cout << "This is function define!" <<" in line "<< line_num  << endl;
        nextsym();      /////////��ʱ������������֮��
        level--;
        if((return_flag==false) && (return_type.compare("VOIDSY")!=0))
        {
            error(18);
        }
        return_flag = false;
        return_expression = false;
    }
}

void mainfunction()
{
    level++;
    if(symbol.compare("VOIDSY")==0)
    {
        return_type = symbol;
        nextsym();
        if(symbol.compare("MAINSY")==0)
        {
            /////////////////////Ƿ�м����
            /////////////////////
            ////////////////////
            nextsym();
            ////////////////////Ƿ���ű�����
            if(symbol.compare("LPAR")==0)
            {
                nextsym();
                if(symbol.compare("RPAR")==0)
                {
                    nextsym();
                    if(symbol.compare("LBRACE")!=0)
                    {
                        error(14);
                    }
                }
                else
                {
                    error(15);
                }
            }
            else
            {
                error(16);
            }
        }
        else
        {
            error(5);
        }
    }
    else
    {
        error(6);
    }
    next_LBRACE();
    compoundstatement();
    if(symbol.compare("RBRACE")!=0)
    {
        error(17);
    }
    ////////////////Ƿ�������
    ///////////////Ƿ�������
    cout << "This main function!" <<" in line "<< line_num  << endl;
    if((return_flag==true)&&(return_expression!=false))
    {
        error(19);
    }
    return_flag = false;
    return_expression = false;
    level--;
}

void vardefine()
{
    while((symbol.compare("INTSY")==0) || (symbol.compare("CHARSY")==0))
    {
        string type = symbol;
        nextsym();
        if(symbol.compare("IDSY")==0)
        {
            string Name = string(IDNAME);
            nextsym();
            if(symbol.compare("LBRACKET")==0)
            {
                nextsym();
                if((symbol.compare("NUMSY")==0) && ((*pre1p)!='0'))
                {
                    int Length = num;
                    nextsym();
                    if(symbol.compare("RBRACKET")!=0)
                    {
                        error(13);               //ȱ��]
                        next_semi();
                        continue;
                    }
                    ///////////////////////Ƿ��
                    //////////////////////Ƿ�м����
                    ////////////////////
                    nextsym();
                }
                else
                {
                    error(9);
                    next_semi();
                    continue;
                }
            }
            else if(symbol.compare("LPAR")==0)
            {
                recallsym();
                recallsym();
                recallsym();
                nextsym();
                return;
            }
            else
            {
                ///////////////////////Ƿ��
                    //////////////////////Ƿ�м����
                    ////////////////////
            }
        }
        else
        {
            error(8);
            nextsym();
            continue;
        }
        int flag = 0;
        while(symbol.compare("COMMA")==0)
        {
            nextsym();
            if(symbol.compare("IDSY")==0)
            {
                string Name = string(IDNAME);
                nextsym();
                if(symbol.compare("LBRACKET")==0)
                {
                    nextsym();
                    if((symbol.compare("NUMSY")==0) && ((*pre1p)!='0'))
                    {
                        int Length = num;
                        nextsym();
                        if(symbol.compare("RBRACKET")!=0)
                        {
                            error(13);               //ȱ��]
                            flag = 1;
                            break;
                        }
                        ///////////////////////Ƿ��
                        //////////////////////Ƿ�м����
                        ////////////////////
                        nextsym();
                    }
                    else
                    {
                        error(9);
                        flag = 1;
                        break;
                    }
                }
                else
                {
                    ///////////////////////Ƿ��
                        //////////////////////Ƿ�м����
                        ////////////////////
                }
            }
            else
            {
                error(8);
                flag = 1;
                break;
            }
        }
        if(flag == 1)
        {
            next_semi();
            continue;
        }
        if(symbol.compare("SEMI")!=0)
        {
            error(12);
        }
        cout << "This is var define!" <<" in line "<< line_num  << endl;
        nextsym();
    }
}

int paratable()
{
    int paranumber = 0;
    if((symbol.compare("INTSY")==0) || (symbol.compare("CHARSY")==0))
    {
        string type = symbol;
        nextsym();
        if(symbol.compare("IDSY")==0)
        {
            string Name = string(IDNAME);
            ////////////////////Ƿһ�����ű�����
            /////////////////////Ƿ�м���뼰����
            paranumber++;
            nextsym();
        }
        else
        {
            error(8);
        }
    }
    else if(symbol.compare("RPAR")==0)
    {
        cout << "This paratable!" <<" in line "<< line_num  << endl;
        return paranumber;
    }
    else
    {
        error(6);
    }
    while(symbol.compare("COMMA")==0)
    {
        nextsym();
        if((symbol.compare("INTSY")==0) || (symbol.compare("CHARSY")==0))
        {
            string type = symbol;
            nextsym();
            if(symbol.compare("IDSY")==0)
            {
                string Name = string(IDNAME);
                ////////////////////Ƿһ�����ű�����
                /////////////////////Ƿ�м���뼰����
                paranumber++;
                nextsym();
            }
            else
            {
                error(8);
                break;
            }
        }
        else
        {
            error(6);
            break;
        }
    }
    next_RPAR();
    cout << "This paratable!" <<" in line "<< line_num  << endl;
    return paranumber;
}

void functioncall()        ///////////////////��ȱ��һ���ж��Ƿ��з���ֵ�ĵ��õı�־
{
    int realparanum = 0;
    if(symbol.compare("IDSY")==0)
    {
        string Name = string(IDNAME);
        nextsym();
        if(symbol.compare("LPAR")==0)
        {
            nextsym();
            if(symbol.compare("RPAR")==0)
            {
                nextsym();
                cout << "This function call!" <<" in line "<< line_num  << endl;
                return;
            }
            expression();
            realparanum ++;
            ///////////////
            ////////////Ƿ�˺ܶ�����ͷ��ű�����
            ////////////
            while(symbol.compare("COMMA")==0)
            {
                nextsym();
                expression();
                realparanum++;
            }
            if(symbol.compare("RPAR")!=0)
            {
                error(15);
                next_semi();
                return;
            }
            /////////////////////
            ////////////////////Ƿ�˺ܶ�����ͷ��ű�����
            ////////////////////
            nextsym();
            cout << "This function call!" <<" in line "<< line_num   << endl;
            return ;
        }
        else
        {
            error(16);
            next_semi();
        }
    }
    else
    {
        error(5);
        next_semi();
    }
}

int expression()
{
    int result=0;
    int flag = 1;
    ////////////
    /////////////
    if((symbol.compare("PLUS")==0) || (symbol.compare("MINUS")==0))
    {
        if(symbol.compare("MINUS")==0)
        {
            //////////////
            flag = -1;
            nextsym();
            /////////////
            /////////////
            /////////////
        }
        else
        {
            nextsym();
            ////////////
            ////////////
            ///////////
        }
    }
    term();   ///////////////////////ע�⣬���������Ҫ������ʱ��term����ÿ�������������
    while((symbol.compare("PLUS")==0) || (symbol.compare("MINUS")==0))
    {
        ////////////
        ////////////
        if(symbol.compare("PLUS")==0)
        {
            nextsym();
            term();
            /////////////////
            //////////////////
            ///////////////////
        }
        else
        {
            nextsym();
            term();
            /////////////////
            ////////////////////
            ///////////////////
        }
    }
    cout << "This expression!" <<" in line "<< line_num   << endl;
    return result;
}

int term()
{
    ////////////
    factor();
    ///////////
    ///////////
    //////////
    while((symbol.compare("STAR")==0) || (symbol.compare("DIVIDE")==0))
    {
        /////
        ////
        int debugf = 0;
        if((symbol.compare("STAR")==0) || (symbol.compare("DIVIDE")==0))
        {
            debugf++;
        }
        if(symbol.compare("STAR")==0)
        {
            nextsym();
            factor();
            ////////////////
            /////////////////
            //////////////////
        }
        else if(symbol.compare("DIVIDE")==0)
        {
            nextsym();
            factor();
            //////////
            /////////
            ////////
        }
    }
    ///////////
    cout << "This term!" <<" in line "<< line_num   << endl;
    return 0;
}

int factor()
{
    if(symbol.compare("IDSY")==0)
    {
        string Name = string(IDNAME);
        nextsym();
        if(symbol.compare("LBRACKET")==0)
        {
            nextsym();
            expression();
            if(symbol.compare("RBRACKET")!=0)
            {
                error(13);
            }
            nextsym();
            ///////////////////////
            ///////////////////////ȴһ�����������ͷ��ű�
            ////////////////////////
            cout << "This is factor" <<" in line "<< line_num   << endl;
            return 1;
        }
        else if(symbol.compare("LPAR")==0)
        {
            recallsym();
            recallsym();
            nextsym();
            //////////
            //////////////
            //////////////ȱһ����������
            functioncall();
            //////////////
            //////////////ȱһ����������
            ///////////////
            cout << "This is factor" <<" in line "<< line_num   << endl;
            return 1;
        }
        else
        {
            ////////////ȴһ����������
            cout << "This is factor" <<" in line "<< line_num   << endl;
            return 1;
        }
    }
    else if((symbol.compare("PLUS")==0) || (symbol.compare("MINUS")==0) || (symbol.compare("NUMSY")==0))
    {
        int NUM;
        NUM = integer();
        ///////////////
        //////////////
        /////////////
        cout << "This is factor" <<" in line "<< line_num   << endl;
        return 1;
    }
    else if(symbol.compare("CHARASCII")==0)
    {
        char tempchar = singleCHAR;
        nextsym();
        /////////////////
        /////////////////
        //////////////////
        cout << "This is factor" <<" in line "<< line_num   << endl;
        return tempchar;
    }
    else if(symbol.compare("LPAR")==0)
    {
        nextsym();
        if(symbol.compare("RPAR")==0)
        {
            error(20);
            nextsym();
            return 0;
        }
        int e_value;
        e_value=expression();
        if(symbol.compare("RPAR")!=0)
        {
            error(15);
            nextsym();
            return 0;
        }
        nextsym();
        ////////////////////
        cout << "This is factor" <<" in line "<< line_num   << endl;
        return e_value;
    }
    else
    {
        error(21);           //////////////////////////////////////////////////////////////////
        nextsym();
        return 0;
    }
}

void compoundstatement()
{
    if(symbol.compare("CONSTSY")==0)
    {
        constdefine();
    }
    if((symbol.compare("INTSY")==0) || (symbol.compare("CHARSY")==0))
    {
        vardefine();
    }
    statementlist();
}

void statementlist()
{
    while((symbol.compare("IFSY")==0) || (symbol.compare("DOSY")==0) || (symbol.compare("SWITCHSY")==0) ||
          (symbol.compare("LBRACE")==0) || (symbol.compare("IDSY")==0) || (symbol.compare("SCANFSY")==0) ||
          (symbol.compare("PRINTSY")==0) || (symbol.compare("SEMI")==0) || (symbol.compare("RETURNSY")==0))
    {
        statement();
            ///////////////Ƿ���
    }
    cout << "This is statementlist!" <<" in line "<< line_num  << endl;
}

void statement()
{
    if(symbol.compare("IFSY")==0)
    {
        conditionalstatement();
    }
    else if(symbol.compare("DOSY")==0)
    {
        loopstatement();
    }
    else if(symbol.compare("SWITCHSY")==0)
    {
        casestatement();
    }
    else if(symbol.compare("LBRACE")==0)
    {
        nextsym();
        statementlist();
        if(symbol.compare("RBRACE")!=0)
        {
            error(17);
            recallsym();
        }
        nextsym();
    }
    else if(symbol.compare("IDSY")==0)
    {
        string Name = string(IDNAME);
        nextsym();
        if(symbol.compare("LBRACKET")==0)
        {
            recallsym();
            recallsym();
            nextsym();
            assignmentstatement();
            /////////////////
            /////////////////
            /////////////////
            if(symbol.compare("SEMI")!=0)
            {
                error(12);
                recallsym();
            }
            nextsym();
        }
        else if(symbol.compare("LPAR")==0)
        {
            recallsym();
            recallsym();
            nextsym();
            functioncall();
            ////////////////////
            /////////////////
            ////////////////////
            if(symbol.compare("SEMI")!=0)
            {
                error(12);
                recallsym();
            }
            nextsym();
        }
        else if(symbol.compare("EQUAL")==0)
        {
            recallsym();
            recallsym();
            nextsym();
            assignmentstatement();
            ///////////////
            /////////////
            ////////////////
            if(symbol.compare("SEMI")!=0)
            {
                error(12);
                recallsym();
            }
            nextsym();
        }
        else
        {
            error(22);
            next_semi();
        }
    }
    else if(symbol.compare("SCANFSY")==0)
    {
        readstatement();
        if(symbol.compare("SEMI")!=0)
        {
            error(12);
            recallsym();
        }
        nextsym();
    }
    else if(symbol.compare("PRINTSY")==0)
    {
        writestatement();
        if(symbol.compare("SEMI")!=0)
        {
            error(12);
            recallsym();
        }
        nextsym();
    }
    else if(symbol.compare("RETURNSY")==0)
    {
        returnstatement();
        if(symbol.compare("SEMI")!=0)
        {
            error(12);
            recallsym();
        }
        nextsym();
    }
    else if(symbol.compare("SEMI")==0)
    {
        nextsym();
    }
    else
    {
        error(23);
        next_semi();
    }
}

void condition()
{
    ////////////////
    ////////////////
    ///////////////
    expression();
    ////////////
    /////////////
    /////////////
    if(symbol.compare("RPAR")==0)
    {
        cout << "This is condition" <<" in line "<< line_num  << endl;
        return;
    }
    else if((symbol.compare("SMALLER")==0) || (symbol.compare("SMALLEREQ")==0) || (symbol.compare("BIGGER")==0) ||
       (symbol.compare("BIGGEREQ")==0) || (symbol.compare("NEQUAL")==0) || (symbol.compare("REALEQ")==0))
    {
        ////////////////////
        ////////////////////
        nextsym();
        expression();
        cout << "This is condition" <<" in line "<< line_num   << endl;
    }
    else
    {
        error(24);
        next_statement();
    }
}

void conditionalstatement()
{
    if(symbol.compare("IFSY")==0)
    {
        nextsym();
        if(symbol.compare("LPAR")==0)
        {
            nextsym();
            condition();
            if(symbol.compare("RPAR")!=0)
            {
                error(15);
                recallsym();
            }
            nextsym();
            ////////
            /////////
            statement();
            /////////////
            ///////////
            cout << "This is conditional statement!" <<" in line "<< line_num << endl;
        }
        else
        {
            error(16);
            recallsym();
            nextsym();
            condition();          ///////////////////
            if(symbol.compare("RPAR")!=0)
            {
                error(15);
                recallsym();
            }
            nextsym();
            ////////
            /////////
            statement();
            ////////////////
            //////////////////
        }
    }
}

void loopstatement()
{
    cout << "This is enter loop statement" <<" in line "<< line_num   << endl;
    if(symbol.compare("DOSY")==0)
    {
        ///////////////////
        ////////////////
        nextsym();
        statement();
        if(symbol.compare("WHILESY")==0)
        {
            nextsym();
            //////////////
            ///////////////
            if(symbol.compare("LPAR")==0)
            {
                nextsym();
                condition();
                if(symbol.compare("RPAR")!=0)
                {
                    error(15);
                    recallsym();
                }
                nextsym();
                cout << "This is loop statement" <<" in line "<< line_num << endl;
            }
            else
            {
                error(16);
                next_statement();
                return ;
            }
        }
        else
        {
            error(25);
            next_statement();
            return;
        }
    }
}

void casestatement()
{
    if(symbol.compare("SWITCHSY")==0)
    {
        nextsym();
        if(symbol.compare("LPAR")==0)
        {
            nextsym();
            //////////////
            //////////////
            expression();
            ////////////
            if(symbol.compare("RPAR")!=0)
            {
                error(15);
                next_LBRACE();
            }
            nextsym();
            if(symbol.compare("LBRACE")==0)
            {
                nextsym();
                casetable();
                if(symbol.compare("RBRACE")!=0)
                {
                    error(17);
                    next_statement();
                }
                nextsym();
                cout << "This is case statement" <<" in line "<< line_num << endl;
            }
            else
            {
                error(14);
            }
        }
        else
        {
            error(16);
        }
    }
}

void casetable()
{
    if(symbol.compare("CASESY")==0)
    {
        nextsym();
        if(symbol.compare("NUMSY")==0)
        {
            /////////
            //////////
            if((*pre1p =='0') && (p-pre1p>1))
            {
                error(9);
            }
            int NUM = num;
            //////////////////
            ///////////////////
            nextsym();
            if(symbol.compare("COLON")==0)
            {
                nextsym();
                statement();
                cout << "This is one of case table" <<" in line "<< line_num << endl;
            }
            else
            {
                error(26);
                next_statement();
            }
        }
        else if(symbol.compare("CHARASCII")==0)
        {
            /////////
            //////////
            char tempchar = singleCHAR;
            //////////////////
            ///////////////////
            nextsym();
            if(symbol.compare("COLON")==0)
            {
                nextsym();
                statement();
                cout << "This is one of case table" <<" in line "<< line_num << endl;
            }
            else
            {
                error(26);
                next_statement();
            }
        }
        else
        {
            error(27);
        }
    }
    while(symbol.compare("CASESY")==0)
    {
        nextsym();
        if(symbol.compare("NUMSY")==0)
        {
            /////////
            //////////
            if((*pre1p =='0') && (p-pre1p>1))
            {
                error(9);
            }
            int NUM = num;
            //////////////////
            ///////////////////
            nextsym();
            if(symbol.compare("COLON")==0)
            {
                nextsym();
                statement();
                cout << "This is one of case table" <<" in line "<< line_num << endl;
            }
            else
            {
                error(26);
                next_statement();
            }
        }
        else if(symbol.compare("CHARASCII")==0)
        {
            /////////
            //////////
            char tempchar = singleCHAR;
            //////////////////
            ///////////////////
            nextsym();
            if(symbol.compare("COLON")==0)
            {
                nextsym();
                statement();
                cout << "This is one of case table" <<" in line "<< line_num << endl;
            }
            else
            {
                error(26);
                next_statement();
            }
        }
        else
        {
            error(27);
        }
    }
}

void assignmentstatement()
{
    if(symbol.compare("IDSY")==0)
    {
        string Name = string(IDNAME);
        //////////////////
        //////////////////
        nextsym();
        if(symbol.compare("LBRACKET")==0)
        {
            nextsym();
            ///////////////////
            //////////////////
            expression();
            /////////////////
            //////////////////
            if(symbol.compare("RBRACKET")!=0)
            {
                error(13);
                recallsym();
            }
            nextsym();
            //////////
            //////////
            if(symbol.compare("EQUAL")!=0)
            {
                error(28);
                recallsym();
            }
            nextsym();
            expression();
            cout << "This is array assign statement" <<" in line "<< line_num << endl;
        }
        else if(symbol.compare("EQUAL")==0)
        {
            nextsym();
            ///////////////////////
            ///////////////////////
            expression();
            ///////////////////////
            ///////////////////////
            cout << "This is assign satement" <<" in line "<< line_num<< endl;
        }
        else
        {
            error(29);
        }
    }
}

void readstatement()
{
    if(symbol.compare("SCANFSY")==0)
    {
        nextsym();
        if(symbol.compare("LPAR")==0)
        {
            nextsym();
            string Name;
            if(symbol.compare("IDSY")==0)
            {
                Name = string(IDNAME);
                ///////////////////
                /////////////////////
                nextsym();

            }
            else
            {
                error(8);
                next_semi();
                return ;
            }
            while(symbol.compare("COMMA")==0)
            {
                nextsym();
                if(symbol.compare("IDSY")==0)
                {
                    Name = string(IDNAME);
                    ///////////////////
                    /////////////////////
                    nextsym();

                }
                else
                {
                    error(8);
                    next_semi;
                    return ;
                }
            }
            if(symbol.compare("RPAR")!=0)
            {
                error(15);
                next_semi();
                return ;
            }
            nextsym();
            cout << "This is read statement" <<" in line "<< line_num << endl;
        }
        else
        {
            error(16);
            next_semi();
            return ;
        }
    }
}

void writestatement()
{
    if(symbol.compare("PRINTSY")==0)
    {
        nextsym();
        if(symbol.compare("LPAR")==0)
        {
            nextsym();
            if(symbol.compare("STRINGSY")==0)
            {
                nextsym();
                if(symbol.compare("COMMA")==0)
                {
                    nextsym();
                    expression();
                }

            }
            else
            {
                expression();
            }
            if(symbol.compare("RPAR")!=0)
            {
                error(15);
                recallsym();
            }
            nextsym();
            cout << "This is write statement��" <<" in line "<< line_num << endl;
        }
        else
        {
            error(16);
            next_semi();
            return ;
        }
    }
}

void returnstatement()
{
    if(symbol.compare("RETURNSY")==0)
    {
        nextsym();
        return_flag = true;
        if(symbol.compare("LPAR")==0)
        {
            nextsym();
            expression();
            return_expression = true;
            if(symbol.compare("RPAR")!=0)
            {
                error(15);
                recallsym();
            }
            nextsym();
            cout << "This is return statement" <<" in line "<< line_num << endl;
        }
        else if(symbol.compare("SEMI")==0)
        {
            cout << "This is return statement" <<" in line "<< line_num << endl;
            return;
        }
        else
        {
            ///////////////
            if(return_type.compare("VOIDSY")!=0)
                error(18);
        }
    }
}
//������    ::= �ۣ�����˵�����ݣۣ�����˵������{���з���ֵ�������壾|���޷���ֵ�������壾}����������
//������˵���� ::=  const���������壾;{ const���������壾;}
//���������壾   ::=   int����ʶ��������������{,����ʶ��������������}
     //                       | char����ʶ���������ַ���{,����ʶ���������ַ���}
//���з���ֵ�������壾  ::=  ������ͷ������(��������������)�� ��{����������䣾��}��
//���޷���ֵ�������壾  ::= void����ʶ������(��������������)����{����������䣾��}��

//����������    ::= void main��(����)�� ��{����������䣾��}��

void program()         //������﷨����
{
    Ch = *p;
    nextsym();
    while(1)
    {
        if(symbol.compare("CONSTSY") == 0)
        {
            constdefine();
        }
        if((symbol.compare("INTSY")==0) || (symbol.compare("CHARSY")==0))
        {
            nextsym();
            if(symbol.compare("IDSY")==0)
            {
                nextsym();
                if(symbol.compare("LPAR")==0)
                {
                    recallsym();
                    recallsym();
                    recallsym();
                    nextsym();
                    functiondefine();
                    mainfunction();
                    return;
                }
                else if((symbol.compare("COMMA")==0) || (symbol.compare("SEMI")==0) || (symbol.compare("LBRACKET")==0))
                {
                    recallsym();
                    recallsym();
                    recallsym();
                    nextsym();
                    vardefine();
                    if((symbol.compare("INTSY")==0) || (symbol.compare("CHARSY")==0))
                    {
                        functiondefine();
                        mainfunction();
                        return;
                    }
                    else if( symbol.compare("VOIDSY")==0)
                    {
                        nextsym();
                        if(symbol.compare("MAINSY")==0)
                        {
                            recallsym();
                            recallsym();
                            nextsym();
                            mainfunction();
                            return;
                        }
                        else if(symbol.compare("IDSY")==0)
                        {
                            recallsym();
                            recallsym();
                            nextsym();
                            functiondefine();
                            mainfunction();
                            return;
                        }
                        else
                        {
                            error(5);
                            next_declare_head();
                            continue;
                        }
                    }
                    else
                    {
                        error(6);
                        next_declare_head();
                        continue;
                    }
                }
                else
                {
                    error(7);
                    next_declare_head();
                    continue;
                }

            }
            else
            {
                error(8);
                next_declare_head();
                continue;
            }
        }
        else if(symbol.compare("VOIDSY")==0) /////////////////////
        {
            nextsym();
            if(symbol.compare("MAINSY")==0)
            {
                recallsym();
                recallsym();
                nextsym();
                mainfunction();
                return;
            }
            else if(symbol.compare("IDSY")==0)
            {
                recallsym();
                recallsym();
                nextsym();
                functiondefine();
                mainfunction();
                return;
            }
            else
            {
                error(5);
                next_declare_head();
                continue;
            }
        }
        else         //////////////////
        {
            error(6);
            next_declare_head();
            continue;
        }
    }
}

