#include "global.h"


using namespace std;

int main()
{
    //cout << "Hello world!" << endl;
    readCodeFile();
    program();
    return 0;
}
