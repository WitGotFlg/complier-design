#include "global.h"

vector<block> blocklist;
int blocklistlength = 0;

bool islocalvar(string var)
{
	int index = getsymindex(var, string("VAR"));
	if ((index != -1) && (symboltable[index].level == 0))
	{
		return false;
	}
	if (var.length() > 0)
	{
		if (!((var.c_str()[0] >= '0') && (var.c_str()[0] <= '9')))
		{
			if (var.length() > 1)
			{
				if ((var.substr(0, 4).compare("TEMP") == 0) || (var.c_str()[0] == '-'))
				{
					return false;
				}
				if (var.c_str()[0] == '\'')
				{
					return false;
				}
			}
			//cout << "in islocalvar true" << endl;
			return true;
		}
		return false;
	}
}

bool if_exit_vector(string obj, vector<string> &vec, int length)
{
	for (int i = 0; i < length; i++)
	{
		if (vec[i].compare(obj) == 0)
		{
			//cout << "in if_exist_vector true" << endl;
			return true;
		}
	}
	return false;
}

int vectorToSet(vector<string> &vec, int length)    //ȥ��vector����ͬ��Ԫ�أ�ʹ֮��Ϊһ������
{
	for (int i = 0; i < length; i++)
	{
		for (int j = i + 1; j < length; j++)
		{
			if (vec[i].compare(vec[j]) == 0)
			{
				vec.erase(vec.begin() + j);
				j--;
				length--;
			}
		}
	}
	//vec.shrink_to_fit();               /////////////////////////
	return length;
}

int calculatein(vector<string> &in, int innum, vector<string> &use, int usenum, vector<string> &out, int outnum, vector<string> &def, int defnum)
{
	//in.clear();
	//in.shrink_to_fit();
	int new_innum = 0;
	for (int i = 0; i < outnum; i++)
	{
		int j;
		for (j = 0; j < defnum; j++)
		{
			if (out[i].compare(def[j]) == 0)
			{
				break;
			}
		}
		if (j == defnum)
		{
			in.push_back(out[i]);
			new_innum++;
		}
	}
	for (int i = 0; i < usenum; i++)
	{
		in.push_back(use[i]);
		new_innum++;
	}
	return vectorToSet(in,innum+new_innum);
}

void dataflowanalysis(int start)
{
	blocklistlength = 0;
	blocklist.clear();
	//blocklist.shrink_to_fit();
	int jlabelcount = 0;
	for (int i = start; middlecode_list[i].op.compare("FEND") != 0; i++)    //����block�Լ�����def��use
	{
		if (middlecode_list[i].op.compare("LABEL") == 0)
		{
			block new_block;
			new_block.prenum = 0;
			new_block.sucnum = 0;
			new_block.defnum = 0;
			new_block.usenum = 0;
			new_block.innum = 0;
			new_block.outnum = 0;
			new_block.inchanged = 0;
			new_block.label = middlecode_list[i].ob3;
			if (blocklistlength > 0) /////////////////////////
			{
				new_block.pre.push_back(blocklist[blocklistlength - 1].label);
				new_block.prenum++;
				blocklist[blocklistlength - 1].suc.push_back(new_block.label);
				blocklist[blocklistlength - 1].sucnum++;
			}
			blocklist.push_back(new_block);
			blocklistlength++;
			continue;
		}
		else if ((middlecode_list[i].op.compare("JBE") == 0) ||
			(middlecode_list[i].op.compare("JB") == 0) ||
			(middlecode_list[i].op.compare("JSE") == 0) ||
			(middlecode_list[i].op.compare("JS") == 0) ||
			(middlecode_list[i].op.compare("JNE") == 0) ||
			(middlecode_list[i].op.compare("JE") == 0) ||
			(middlecode_list[i].op.compare("JUMP") == 0) ||
			(middlecode_list[i].op.compare("JNEI") == 0) ||
			(middlecode_list[i].op.compare("JNEC") == 0))
		{
			if (islocalvar(middlecode_list[i].ob1) &&
				!if_exit_vector(middlecode_list[i].ob1, blocklist[blocklistlength - 1].def, blocklist[blocklistlength - 1].defnum))
			{
				blocklist[blocklistlength - 1].use.push_back(middlecode_list[i].ob1);
				blocklist[blocklistlength - 1].usenum++;
			}
			if (islocalvar(middlecode_list[i].ob2) &&
				!if_exit_vector(middlecode_list[i].ob2, blocklist[blocklistlength - 1].def, blocklist[blocklistlength - 1].defnum))
			{
				blocklist[blocklistlength - 1].use.push_back(middlecode_list[i].ob2);
				blocklist[blocklistlength - 1].usenum++;
			}
			block new_block;
			new_block.prenum = 0;
			new_block.sucnum = 0;
			new_block.defnum = 0;
			new_block.usenum = 0;
			new_block.innum = 0;
			new_block.outnum = 0;
			new_block.inchanged = 0;
			stringstream temp_s;
			temp_s << jlabelcount++;
			new_block.label = "jlabel" + temp_s.str();
			blocklist[blocklistlength - 1].suc.push_back(middlecode_list[i].ob3);
			blocklist[blocklistlength - 1].sucnum++;
			if (blocklistlength > 0 && middlecode_list[i].op.compare("JUMP") != 0)
			{
				new_block.pre.push_back(blocklist[blocklistlength - 1].label);
				new_block.prenum++;
				blocklist[blocklistlength - 1].suc.push_back(new_block.label);
				blocklist[blocklistlength - 1].sucnum++;
			}
			blocklist.push_back(new_block);
			blocklistlength++;
			continue;
		}
		else if ((middlecode_list[i].op.compare("RCALL") == 0) || (middlecode_list[i].op.compare("PARA") == 0))
		{
			blocklist[blocklistlength - 1].def.push_back(middlecode_list[i].ob3);
			blocklist[blocklistlength - 1].defnum++;
		}
		else if ((middlecode_list[i].op.compare("ADD") == 0) ||
			(middlecode_list[i].op.compare("SUB") == 0) ||
			(middlecode_list[i].op.compare("MUL") == 0) ||
			(middlecode_list[i].op.compare("DIV") == 0))
		{
			if (islocalvar(middlecode_list[i].ob1) &&
				!if_exit_vector(middlecode_list[i].ob1, blocklist[blocklistlength - 1].def, blocklist[blocklistlength - 1].defnum))
			{
				blocklist[blocklistlength - 1].use.push_back(middlecode_list[i].ob1);
				blocklist[blocklistlength - 1].usenum++;
			}
			if (islocalvar(middlecode_list[i].ob2) &&
				!if_exit_vector(middlecode_list[i].ob2, blocklist[blocklistlength - 1].def, blocklist[blocklistlength - 1].defnum))
			{
				blocklist[blocklistlength - 1].use.push_back(middlecode_list[i].ob2);
				blocklist[blocklistlength - 1].usenum++;
			}
			if (islocalvar(middlecode_list[i].ob3) &&
				!if_exit_vector(middlecode_list[i].ob3, blocklist[blocklistlength - 1].use, blocklist[blocklistlength - 1].usenum))
			{
				blocklist[blocklistlength - 1].def.push_back(middlecode_list[i].ob3);
				blocklist[blocklistlength - 1].defnum++;
			}
		}
		else if (middlecode_list[i].op.compare("ASN") == 0)
		{
			if (islocalvar(middlecode_list[i].ob1) &&
				!if_exit_vector(middlecode_list[i].ob1, blocklist[blocklistlength - 1].def, blocklist[blocklistlength - 1].defnum))
			{
				blocklist[blocklistlength - 1].use.push_back(middlecode_list[i].ob1);
				blocklist[blocklistlength - 1].usenum++;
			}
			if (islocalvar(middlecode_list[i].ob3) &&
				!if_exit_vector(middlecode_list[i].ob3, blocklist[blocklistlength - 1].use, blocklist[blocklistlength - 1].usenum))
			{
				blocklist[blocklistlength - 1].def.push_back(middlecode_list[i].ob3);
				blocklist[blocklistlength - 1].defnum++;
			}
		}
		else if (middlecode_list[i].op.compare("GETAR") == 0)
		{
			if (islocalvar(middlecode_list[i].ob2) &&
				!if_exit_vector(middlecode_list[i].ob2, blocklist[blocklistlength - 1].def, blocklist[blocklistlength - 1].defnum))
			{
				blocklist[blocklistlength - 1].use.push_back(middlecode_list[i].ob2);
				blocklist[blocklistlength - 1].usenum++;
			}
			if (islocalvar(middlecode_list[i].ob3) &&
				!if_exit_vector(middlecode_list[i].ob3, blocklist[blocklistlength - 1].use, blocklist[blocklistlength - 1].usenum))
			{
				blocklist[blocklistlength - 1].def.push_back(middlecode_list[i].ob3);
				blocklist[blocklistlength - 1].defnum++;
			}
		}
		else if (middlecode_list[i].op.compare("ASNAR") == 0)
		{
			if (islocalvar(middlecode_list[i].ob1) &&
				!if_exit_vector(middlecode_list[i].ob1, blocklist[blocklistlength - 1].def, blocklist[blocklistlength - 1].defnum))
			{
				blocklist[blocklistlength - 1].use.push_back(middlecode_list[i].ob1);
				blocklist[blocklistlength - 1].usenum++;
			}
			if (islocalvar(middlecode_list[i].ob2) &&
				!if_exit_vector(middlecode_list[i].ob2, blocklist[blocklistlength - 1].def, blocklist[blocklistlength - 1].defnum))
			{
				blocklist[blocklistlength - 1].use.push_back(middlecode_list[i].ob2);
				blocklist[blocklistlength - 1].usenum++;
			}
		}
		else if ((middlecode_list[i].op.compare("RETURN") == 0) || (middlecode_list[i].op.compare("PUSH") == 0))
		{
			if (islocalvar(middlecode_list[i].ob3) &&
				!if_exit_vector(middlecode_list[i].ob3, blocklist[blocklistlength - 1].def, blocklist[blocklistlength - 1].defnum))
			{
				blocklist[blocklistlength - 1].use.push_back(middlecode_list[i].ob3);
				blocklist[blocklistlength - 1].usenum++;
			}
		}
		else if (middlecode_list[i].op.compare("SCANF") == 0)
		{
			if (islocalvar(middlecode_list[i].ob3) &&
				!if_exit_vector(middlecode_list[i].ob3, blocklist[blocklistlength - 1].use, blocklist[blocklistlength - 1].usenum))
			{
				blocklist[blocklistlength - 1].def.push_back(middlecode_list[i].ob3);
				blocklist[blocklistlength - 1].defnum++;
			}
		}
		else if (middlecode_list[i].op.compare("PRINTF") == 0)
		{
			if (islocalvar(middlecode_list[i].ob2) &&
				!if_exit_vector(middlecode_list[i].ob2, blocklist[blocklistlength - 1].def, blocklist[blocklistlength - 1].defnum))
			{
				blocklist[blocklistlength - 1].use.push_back(middlecode_list[i].ob2);
				blocklist[blocklistlength - 1].usenum++;
			}
		}
		else if ((middlecode_list[i].op.compare("INTSY") == 0) ||
			(middlecode_list[i].op.compare("CHARSY") == 0))
		{
			if (islocalvar(middlecode_list[i].ob1) &&
				!if_exit_vector(middlecode_list[i].ob1, blocklist[blocklistlength - 1].def, blocklist[blocklistlength - 1].defnum))
			{
				blocklist[blocklistlength - 1].use.push_back(middlecode_list[i].ob1);
				blocklist[blocklistlength - 1].usenum++;
			}
			if (islocalvar(middlecode_list[i].ob2) &&
				!if_exit_vector(middlecode_list[i].ob2, blocklist[blocklistlength - 1].def, blocklist[blocklistlength - 1].defnum))
			{
				blocklist[blocklistlength - 1].use.push_back(middlecode_list[i].ob2);
				blocklist[blocklistlength - 1].usenum++;
			}
		}
	}

	while (1)
	{
		for (int i = 0; i < blocklistlength; i++)
		{
			int len = 0;
			for (int j = 0; j < blocklist[i].sucnum; j++)
			{
				for (int q = 0; q < blocklistlength; q++)
				{
					if (blocklist[q].label.compare(blocklist[i].suc[j]) == 0)
					{
						for (int p = 0; p < blocklist[q].innum; p++)
						{
							blocklist[i].out.push_back(blocklist[q].in[p]);
							len++;
						}
					}
				}
			}
			blocklist[i].outnum = vectorToSet(blocklist[i].out, len);
			int newinnum = calculatein(blocklist[i].in, blocklist[i].innum, blocklist[i].use, blocklist[i].usenum, blocklist[i].out, blocklist[i].outnum, blocklist[i].def, blocklist[i].defnum);
			if (blocklist[i].innum != newinnum)
			{
				blocklist[i].inchanged = 1;
				blocklist[i].innum = newinnum;
			}
			else
			{
				blocklist[i].inchanged = 0;
			}
		}
		int ier;
		for (ier = 0; ier < blocklistlength; ier++)
		{
			if (blocklist[ier].inchanged == 1)
				break;
		}
		if (ier == blocklistlength)
			break ;                  //////////////////////
	}
}

int getvectorINDEX(string obj, vector<string> &vec, int length)
{
	for (int i = 0; i < length; i++)
	{
		if (vec[i].compare(obj) == 0)
		{
			return i;
		}
	}
	return -1;
}

void REGISTERallocation(int start)
{
	vector<string> varlist;
	int varnum = 0;
	vector<string> stack;
	int stackTop = 0;
	vector<string> abandonstack;
	int abandonstackTop = 0;
	int conflict_graph[100][100] = { 0 };
	int conflict_graph_2[100][100] = { 0 };

	dataflowanalysis(start);
	//cout << "end of dataflowanalysis" << endl;
/*	for (int i= 0; i < blocklistlength; i++)
	{
		cout << "~~~~~~~~~~~~~def~~~~~~~~~~~~~~" << endl;
		for (int j = 0; j < blocklist[i].defnum; j++)
		{
			cout << blocklist[i].def[j] << endl;
		}
		cout << "~~~~~~~~~~~~~def~~~~~~~~~~~~~~" << endl;
		cout << "~~~~~~~~~~~~~use~~~~~~~~~~~~~~" << endl;
		for (int j = 0; j < blocklist[i].usenum; j++)
		{
			cout << blocklist[i].use[j] << endl;
		}
		cout << "-------------use--------------" << endl;
	}*/
////////////////////////////////////////////////////////////////////
	for (int i = 0; i < blocklistlength; i++)                //������ͻͼ���ڶ�����ͻͼ����Ϊ����ʹ��
	{
		for (int j = 0; j < blocklist[i].innum; j++)            //��������in�г��ֵı������ظ��ļ���varlist
		{
			if (!if_exit_vector(blocklist[i].in[j], varlist, varnum))
			{
				if (blocklist[i].in[j].compare("") != 0)
				{
					varlist.push_back(blocklist[i].in[j]);
					varnum++;
				}
			}
		}
		for (int j = 0; j < blocklist[i].innum; j++)             //����ͬһ��in�����еı�����ı���Ϊ1
		{
			if (blocklist[i].in[j].compare("") != 0)
			{
				int temp1 = getvectorINDEX(blocklist[i].in[j], varlist, varnum);
				for (int q = j + 1; q < blocklist[i].innum; q++)
				{
					if (blocklist[i].in[q].compare("") != 0)
					{
						int temp2 = getvectorINDEX(blocklist[i].in[q], varlist, varnum);
						if (temp1 == -1 || temp2 == -1)
						{
							cout << "error in REGISTERallocation!!" << endl;
							exit(1);
						}
						//cout << "uuuuuuuuuuuuu "<<temp1<<" uuuuuuuuuu "<<temp2<<" uuuuuuu"<<endl;
						conflict_graph[temp1][temp2] = 1;
						conflict_graph[temp2][temp1] = 1;
						conflict_graph_2[temp1][temp2] = 1;
						conflict_graph_2[temp2][temp1] = 1;
					}
				}
			}
		}
		/////////////////
		for (int j = 0; j < blocklist[i].outnum; j++)            //��������out�г��ֵı������ظ��ļ���varlist
		{
			if (!if_exit_vector(blocklist[i].out[j], varlist, varnum))
			{
				if (blocklist[i].out[j].compare("") != 0)
				{
					varlist.push_back(blocklist[i].out[j]);
					varnum++;
				}
			}
		}
		for (int j = 0; j < blocklist[i].outnum; j++)             //����ͬһ��out�����еı�����ı���Ϊ1
		{
			if (blocklist[i].out[j].compare("") != 0)
			{
				int temp1 = getvectorINDEX(blocklist[i].out[j], varlist, varnum);
				for (int q = j + 1; q < blocklist[i].outnum; q++)
				{
					if (blocklist[i].out[q].compare("") != 0)
					{
						int temp2 = getvectorINDEX(blocklist[i].out[q], varlist, varnum);
						if (temp1 == -1 || temp2 == -1)
						{
							cout << "error in REGISTERallocation!!" << endl;
							exit(1);
						}
						//cout << "uuuuuuuuuuuuu " << temp1 << " uuuuuuuuuu " << temp2 << " uuuuuuu" << endl;
						conflict_graph[temp1][temp2] = 1;
						conflict_graph[temp2][temp1] = 1;
						conflict_graph_2[temp1][temp2] = 1;
						conflict_graph_2[temp2][temp1] = 1;
					}
				}
			}
		}
	}

/*	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	for (int i = 0; i < varnum; i++)
	{
		cout << varlist[i] << endl;
	}
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << conflict_graph_2[4][6] << endl;
	cout << conflict_graph_2[6][4] << endl;
	cout << conflict_graph_2[3][5] << endl;
	cout << conflict_graph_2[5][3] << endl;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;*/
	//////////////////////////�Գ�ͻͼ���д�����ȥ��һ���ֳ�ͻ��Ϊ���صĽڵ㣬ʹ��ʣ�µĽڵ��ܹ���󻯵����üĴ���
	int varnum2 = varnum;
	int conflicttime[100] = { 0 };   //������ÿһ�������ĳ�ͻ����������
	for (int i = 0; i < varnum; i++)          //�����ͻ��
	{
		for (int j = 0; j < varnum; j++)
		{
			if (conflict_graph[i][j] == 1)
				conflicttime[i]++;
		}
	}
	for (int i = 0, flag = 0; varnum != 0;)
	{
		if (i == 0)
			flag = 0;
		if (conflicttime[i] < 17 && !if_exit_vector(varlist[i], stack, stackTop))
		{
			flag = 1;
			for (int j = 0; j < varnum; j++)
			{
				conflict_graph[i][j] = 0;
				if (conflict_graph[j][i] == 1)
				{
					conflicttime[j]--;
					conflict_graph[j][i] = 0;
				}
			}
			conflicttime[i] = 0;
			stack.push_back(varlist[i]);
			stackTop++;
			varnum2--;              //��ͻͼ�л�ʣ��ı�����
		}
		i = (i + 1) % varnum;
		if (i == 0 && flag == 0)             //˵���Ѿ�û���ܹ���ջ�ĳ�ͻ��С��8�ı�����
			break;
	}
	while (varnum2 != 0)
	{
		int maxconflict = 0;
		int maxindex = 0;
		for (int i = 0; i < varnum; i++)
		{
			if (conflicttime[i] > maxconflict)
			{
				maxconflict = conflicttime[i];
				maxindex = i;
			}
		}
		abandonstack.push_back(varlist[maxindex]);
		abandonstackTop++;

		for (int j = 0; j < varnum; j++)                  //������ͻ���Ľڵ�ȥ��
		{
			conflict_graph[maxindex][j] = 0;
			if (conflict_graph[j][maxindex] == 1)
			{
				conflicttime[j]--;
				conflict_graph[j][maxindex] = 0;
			}
		}
		conflicttime[maxindex] = 0;
		varnum2--;

		for (int i = 0, flag = 0;;)            //���¼�һ����������Ľڵ�
		{
			if (i == 0)
				flag = 0;
			if (conflicttime[i] < 17 &&
				!if_exit_vector(varlist[i], stack, stackTop) &&
				!if_exit_vector(varlist[i], abandonstack, abandonstackTop))
			{
				flag = 1;
				for (int j = 0; j < varnum; j++)
				{
					conflict_graph[i][j] = 0;
					if (conflict_graph[j][i] == 1)
					{
						conflicttime[j]--;
						conflict_graph[j][i] = 0;
					}
				}
				conflicttime[i] = 0;
				stack.push_back(varlist[i]);
				stackTop++;
				varnum2--;              //��ͻͼ�л�ʣ��ı�����
			}
			i = (i + 1) % varnum;
			if (i == 0 && flag == 0)             //˵���Ѿ�û���ܹ���ջ�ĳ�ͻ��С��8�ı�����
				break;
		}

	}
//���г�ͻͼ���޸�
/////////////////////////////////////��ɫ
	vector<string> alreadyallocated;
	int alreadynum = 0;
	int usedsign[17] = { 0 };
	for (int i = stackTop - 1; i >= 0; i--)
	{

		for (int j = 0; j < alreadynum; j++)
		{
			int temp1 = getvectorINDEX(stack[i], varlist, varnum);
			int temp2 = getvectorINDEX(alreadyallocated[j], varlist, varnum);
			if (temp1 == -1 || temp2 == -1)
			{
				cout << "error in allocating register color" << endl;
				exit(1);
			}
			if (conflict_graph_2[temp1][temp2] == 1 || conflict_graph_2[temp2][temp1] == 1)
			{
				string reg = REGISTER[alreadyallocated[j]];
				stringstream temp_s;
				if (reg.substr(0, 2).compare("$s") == 0)
				{
					int temp_num;
					temp_s << reg.erase(0, 2);
					temp_s >> temp_num;
/*					cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
					cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
					cout << temp_num << " !!!!!!reg!!!!!" <<endl;
					cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
					cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
*/
					usedsign[temp_num] = 1;
				}
				else if (reg.substr(0, 2).compare("$t") == 0)
				{
					int temp_num;
					temp_s << reg.erase(0, 2);
					temp_s >> temp_num;
					temp_num = temp_num + 4;
					usedsign[temp_num] = 1;
				}
				else if (reg.substr(0, 2).compare("$a") == 0)
				{

					int temp_num;
					temp_s << reg.erase(0, 2);
					temp_s >> temp_num;
					temp_num = temp_num + 13;
					usedsign[temp_num] = 1;
				}
			/*	temp_s << reg.erase(0,2);
				temp_s >> temp_num;
				usedsign[temp_num] = 1;*/
			}
		}
		int j;
		for (j = 0; j < 17; j++)
		{
			if (usedsign[j] == 0)
			{
				if (j < 8)
				{
				    usedsign[j] = 1;
					stringstream temp_s;
					temp_s << j;
					REGISTER.insert(make_pair(stack[i], "$s" + temp_s.str()));
					alreadyallocated.push_back(stack[i]);
					alreadynum++;
					break;
				}
				else if (j >= 8 && j < 14)
				{
				    usedsign[j] = 1;
					stringstream temp_s;
					temp_s << j - 4;
					REGISTER.insert(make_pair(stack[i], "$t" + temp_s.str()));
					alreadyallocated.push_back(stack[i]);
					alreadynum++;
					break;
				}
				else if(j >=14 && j < 17)
				{
				    usedsign[j] = 1;
					stringstream temp_s;
					temp_s << j - 13;
					REGISTER.insert(make_pair(stack[i], "$a" + temp_s.str()));
					alreadyallocated.push_back(stack[i]);
					alreadynum++;
					break;
				}
/*				stringstream temp_s;
				temp_s << j;
				REGISTER.insert(make_pair(stack[i], "$s" + temp_s.str()));
				alreadyallocated.push_back(stack[i]);
				alreadynum++;
				break;    */
			}
		}
		if (j == 17)
			break;
	}

/*	map<string,string>::iterator  it=REGISTER.begin();
	for(;it!= REGISTER.end();++it)
	cout<<"key:"<<it->first << " "
	<<"value:"<<it->second<<endl;
	cout<<"----------------"<<endl;*/

	return;
}
